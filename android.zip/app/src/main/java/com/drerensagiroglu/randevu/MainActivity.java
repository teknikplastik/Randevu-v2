package com.drerensagiroglu.randevu;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}