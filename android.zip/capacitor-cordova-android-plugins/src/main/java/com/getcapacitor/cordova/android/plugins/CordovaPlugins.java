package com.getcapacitor.cordova.android.plugins;

public class CordovaPlugins {
    // Empty class for Capacitor Cordova plugins
}